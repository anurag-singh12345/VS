package com.center.Exception;

public class VaccineCentreException extends Exception {
	public VaccineCentreException() {
		// TODO Auto-generated constructor stub
	}
	public VaccineCentreException(String message) {
		
		super(message);
	}

}