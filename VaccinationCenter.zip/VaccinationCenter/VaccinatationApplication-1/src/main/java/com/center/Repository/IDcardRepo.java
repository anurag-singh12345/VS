package com.center.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.center.model.AdharCard;
import com.center.model.IDCard;
import com.center.model.Pancard;

@Repository
public interface IDcardRepo extends JpaRepository<IDCard, Integer> {

	public IDCard findByPancard(Pancard pancard);
	
	public IDCard findByAdharcard(AdharCard adharcard);
	
}