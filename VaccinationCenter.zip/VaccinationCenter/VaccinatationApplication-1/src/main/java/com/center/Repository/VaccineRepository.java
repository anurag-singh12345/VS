package com.center.Repository;

public interface VaccineRepository {

}
