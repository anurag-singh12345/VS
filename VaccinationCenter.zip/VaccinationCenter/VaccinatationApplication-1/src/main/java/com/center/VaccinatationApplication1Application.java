package com.center;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaccinatationApplication1Application {

	public static void main(String[] args) {
		SpringApplication.run(VaccinatationApplication1Application.class, args);
	}

}
