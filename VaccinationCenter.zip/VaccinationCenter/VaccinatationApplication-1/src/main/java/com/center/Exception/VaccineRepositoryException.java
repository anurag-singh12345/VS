package com.center.Exception;


public class VaccineRepositoryException extends Exception {
	public VaccineRepositoryException() {
		// TODO Auto-generated constructor stub
	}
	public VaccineRepositoryException(String message) {
		
		super(message);
	}

}