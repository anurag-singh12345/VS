package com.center.Exception;


public class VaccineRegistrationException extends Exception {
	public VaccineRegistrationException() {
		// TODO Auto-generated constructor stub
	}
	public VaccineRegistrationException(String message) {
		
		super(message);
	}

}