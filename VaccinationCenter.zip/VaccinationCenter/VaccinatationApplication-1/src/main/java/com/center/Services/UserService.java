package com.center.Services;

import com.center.Exception.UserException;
import com.center.model.User;
import com.center.model.UserDto;

public interface UserService {
	
	public User createNewUser(User user) throws UserException;
	
	public User updateUser(User user,String password) throws UserException;
	
	public User removeUser(UserDto usrDto) throws UserException;

}