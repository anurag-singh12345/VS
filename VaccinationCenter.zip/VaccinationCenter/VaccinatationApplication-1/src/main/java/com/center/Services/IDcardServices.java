package com.center.Services;


import com.center.Exception.IdCardException;
import com.center.model.IDCard;
import com.center.model.Pancard;

public interface IDcardServices {

	
	public IDCard addIdCard(IDCard id) throws IdCardException; 
	
	public IDCard getIdcardByPanNo(String panNo,String key) throws IdCardException;

	public IDCard getIdCardByAdharNo(Long adharno,String key) throws IdCardException;
	
}