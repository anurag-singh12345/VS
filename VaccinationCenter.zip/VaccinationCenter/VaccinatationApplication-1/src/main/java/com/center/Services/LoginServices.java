package com.center.Services;


import com.center.Exception.LoginException;
import com.center.model.AdminDto;
import com.center.model.UserDto;

public interface LoginServices {
	
	public String logInToUserAccount(UserDto udto) throws LoginException;
	
	public String logOutFromUserAccount(String key) throws LoginException;
	
	public String logInToAdminAccount(AdminDto adto) throws LoginException;
	
	public String logOutFromAdminAccount(String key) throws LoginException;

}