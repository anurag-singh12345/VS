package com.center.Services;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.center.Exception.LoginException;
import com.center.model.Admin;
import com.center.model.AdminDto;
import com.center.model.CurrentAdminSession;
import com.center.model.CurrentUserSession;
import com.center.model.User;
import com.center.model.UserDto;
import com.center.Repository.AdminRepository;
import com.center.Repository.AdminSessionRepository;
import com.center.Repository.UserRepository;
import com.center.Repository.UserSessionRepository;

import net.bytebuddy.utility.RandomString;

@Service
public class LoginServiceImpl implements LoginServices{
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private UserSessionRepository userSession;
	
	@Autowired
	private AdminRepository adminRepo;
	
	@Autowired
	private AdminSessionRepository adminSession;

	@Override
	public String logInToUserAccount(UserDto udto) throws LoginException {
		
		User existingUser = userRepo.findByMobileNo(udto.getMobileNo());
		
		if(existingUser == null) {
			throw new LoginException("No User Found with this Mobile Number !");
		}
		
		Optional<CurrentUserSession> validUserSessionOpt = userSession.findByUserId(existingUser.getId());
		
//		System.out.println(validUserSessionOpt.get());
		
		if(validUserSessionOpt.isPresent()) {
			throw new LoginException("User Already logged In with this Number !");
		}
		
		if(existingUser.getPassword().equals(udto.getPassword())) {
			
			
			String key = RandomString.make(6);
			
			CurrentUserSession cus =  
					new CurrentUserSession(existingUser.getId(), key,LocalDateTime.now());
			
			userSession.save(cus);
			
			return cus.toString();
			
			
		}else {
			throw new LoginException("Please Enter a valid password");
		}
		
	}

	@Override
	public String logOutFromUserAccount(String key) throws LoginException {
		
		Optional<CurrentUserSession> validUserSession =  userSession.findByUuid(key);
		
		if(validUserSession.isPresent()) {
			CurrentUserSession cus=(validUserSession.get());
					userSession.delete(cus);
			return cus.getUserId()+" User Logged Out Successfully !";
			
		}
		
		throw new LoginException("User Not Logged In with this number");
	}

	@Override
	public String logInToAdminAccount(AdminDto adto) throws LoginException {

		Admin existingAdmin = 	adminRepo.findByMobileNo(adto.getMobileNo());
		
		Optional<CurrentAdminSession> validAdminSessionOpt = adminSession.findByAdminId(existingAdmin.getId());
		
		if(existingAdmin == null || !existingAdmin.getPassword().equals(adto.getPassword())) {
			throw new LoginException("No Admin Found with this Mobile Number or password is incorrect... !");
		}
		
	
		if(validAdminSessionOpt.isPresent()) {
			throw new LoginException("Admin is Already logged In with this Number !");
		}
		
		if(existingAdmin.getPassword().equals(adto.getPassword())) {
			
			
			String key = RandomString.make(6);
			
			CurrentAdminSession cas =  
					new CurrentAdminSession(existingAdmin.getId(), key,LocalDateTime.now());
			
			adminSession.save(cas);
			
			return cas.toString();
			
			
		}else {
			throw new LoginException("Please Enter a valid password");
		}
		
	}

	@Override
	public String logOutFromAdminAccount(String key) throws LoginException {
		
		Optional<CurrentAdminSession> validAdminSession =  adminSession.findByUuid(key);
		
		if(validAdminSession.isPresent()) {
			CurrentAdminSession cas=validAdminSession.get();
					adminSession.delete(cas);
			return cas.getAdminId()+" Admin Logged Out Successfully !";
		}
		
		throw new LoginException("Admin Not Logged In with this UUID");
	}

}