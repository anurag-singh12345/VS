package com.center.Exception;


public class IdCardException extends Exception {

	public IdCardException() {
		// TODO Auto-generated constructor stub
	}
	public IdCardException(String message) {
		
		super(message);
	}
}