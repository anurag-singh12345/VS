package com.center.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.center.model.VaccineRegistration;

public interface VaccineRegistrationRepository extends JpaRepository<VaccineRegistration, String>{

}