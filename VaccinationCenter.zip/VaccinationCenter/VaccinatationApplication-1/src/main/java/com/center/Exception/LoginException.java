package com.center.Exception;

public class LoginException extends Exception{

	public LoginException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoginException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
