package com.center.Exception;

public class VaccineInventoryException extends Exception {
	public VaccineInventoryException() {
		// TODO Auto-generated constructor stub
	}
	public VaccineInventoryException(String message) {
		
		super(message);
	}

}