package com.center.Services;

import com.center.Exception.UserException;
import com.center.model.Admin;
import com.center.model.AdminDto;

public interface AdminService {
	
	public Admin createNewAdmin(Admin admin) throws UserException;
	
	public Admin updateAdmin(Admin admin,String password) throws UserException;
	
	public Admin removeAdmin(AdminDto adminDto) throws UserException;
}