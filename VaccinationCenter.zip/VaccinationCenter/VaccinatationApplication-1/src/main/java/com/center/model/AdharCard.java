package com.center.model;

import javax.validation.constraints.Digits;

//@Data
//@AllArgsConstructor
//@NoArgsConstructor
public class AdharCard {
	
	
	@Digits(integer = 12,fraction = 12, message = "aadhar Id must be 12 digits")
	private long adharNo;

	public long getAdharNo() {
		return adharNo;
	}

	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}

	public AdharCard() {
		super();
	}

	public AdharCard(long adharNo) {
		super();
		this.adharNo = adharNo;
	}
	
	

}