package com.center.Repository;

public interface AppointmentRepo {

}
