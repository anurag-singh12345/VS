package com.center.Exception;



public class AppointmentException extends Exception {
	
public AppointmentException() {
	
}
public AppointmentException(String message) {
	super(message);
}
}