package com.center.Exception;

public class VaccineException extends Exception {
	public VaccineException() {
		// TODO Auto-generated constructor stub
	}
	public VaccineException(String message) {
		
		super(message);
	}
}